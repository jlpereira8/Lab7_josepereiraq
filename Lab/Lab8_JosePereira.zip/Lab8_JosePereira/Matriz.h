//
// Created by jlpereira on 11/30/18.
//

#ifndef LAB8_JOSEPEREIRA_MATRIZ_H
#define LAB8_JOSEPEREIRA_MATRIZ_H

#include "string"
using std::string;

class Matriz {
private:
    int size;
    string nombre;
    int** mat;
public:
    Matriz();

    Matriz(int size, const string &nombre, int **mat);

    virtual ~Matriz();

    int getSize() const;

    void setSize(int size);

    const string &getNombre() const;

    void setNombre(const string &nombre);

    int **getMat() const;

    void setMat(int **mat);

    //secso
    int determinante();

    int** operator|(int** m2);
    void operator++();
    void operator--();
    int** operator>(int k);
    int** operator&(int** m);
    int** operator+(int** m);






};


#endif //LAB8_JOSEPEREIRA_MATRIZ_H
