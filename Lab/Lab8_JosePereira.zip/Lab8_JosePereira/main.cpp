#include <iostream>
#include "string"
#include "vector"
#include "Matriz.h"

using std::vector;
using std::cout;
using std::cin;
using std::endl;

int** createIntMatrix(int);

//inicializa la matriz
void initIntMatrix(int**,int);

//Imprime una matriz n*n enteros
void printIntMatrix(int**,int);

//liberar una matriz de n*n enteros
void freeIntMatrix(int**&,int);


int main() {
    int wh = 0;
    int des;
    vector<Matriz*> matrices;
    while (wh == 0) {
        cout << "*************MENU*************" << endl;
        cout << "1) Crear Matriz" << endl;
        cout << "2) Listar Matriz" << endl;
        cout << "3) Eliminar Matriz" << endl;
        cout << "4) Operaciones con Matrices" << endl;
        cout << "5) Salir" << endl;
        cout << "Ingrese su desicion: " << endl;
        cin >> des;
        if (des == 1) {
            int size;
            int nepe;
            string nombre;
            cout << "*************Crear Matriz*************" << endl;
            cout<<"Ingrese el nombre de la matriz"<<endl;
            cin>>nombre;
            cout << "Ingrese el tamano de la matriz" << endl;
            cout << "1) 2 " << endl;
            cout << "2) 3 " << endl;
            cin>>nepe;
            if(nepe==1){
                size=2;
                int** matriz=createIntMatrix(size);
                initIntMatrix(matriz,size);
                printIntMatrix(matriz,size);
                Matriz* m=new Matriz(size,nombre,matriz);
                matrices.push_back(m);
                cout<<"Matriz 2*2 creada Correctamente!"<<endl;
                //cout<<m->determinante();

            }else if(nepe==2){
                size=3;
                int** matriz=createIntMatrix(size);
                initIntMatrix(matriz,size);
                printIntMatrix(matriz,size);
                Matriz* m=new Matriz(size,nombre,matriz);
                matrices.push_back(m);
                cout<<"Matriz 3*3 creada Correctamente!"<<endl;
            }else{
                cout<<"DAto no valido!!"<<endl;
            }

        } else if (des == 2) {
            cout << "*************Listar Matrices*************" << endl;
            cout<<endl;
            for (int i = 0; i <matrices.size() ; ++i) {
                printIntMatrix(matrices.at(i)->getMat(),matrices.at(i)->getSize());
            }

        } else if (des == 3) {
            cout << "*************Eliminar Matrices*************" << endl;
            cout<<endl;
            for (int i = 0; i <matrices.size() ; ++i) {
                printIntMatrix(matrices.at(i)->getMat(),matrices.at(i)->getSize());
            }
            cout<<"Ingrese la posicion de la matriz a eliminar: "<<endl;
            int y; delete matrices.at(y);
            cin>>y;

            matrices.erase(matrices.begin()+y,matrices.begin()+y+1);
        } else if (des == 4) {
            string prob;
            int op;
            // 1= | (suma)
            // 2= ++ (incremento)
            // 3= -- (decremento)
            // 4= > (multiplicacion por escala)
            // 5= &  (Producto entre matrices)
            // 6= + (Suma dentro del espacio vectorial)
            // 7= * (Multiplicación dentro del espacio vectorial)
            cout<<"Ingrese la operacion caballero: "<<endl;
            cin>>prob;
            string izq;
            int mitad;
            for (int i = 0; i <prob.size() ; ++i) {
                if(prob[i]=='|'){
                    op=1;
                    mitad=i;
                    break;
                }if(prob[i]=='+'&&prob[i+1]=='+'){
                    op=2;
                    mitad=i;
                    break;
                }if(prob[i]=='-'&&prob[i+1]=='-'){
                    op=3;
                    mitad=i;
                    break;
                }if(prob[i]=='>'){
                    op=4;
                    mitad=i;
                    break;
                }if(prob[i]=='&'){
                    op=5;
                    mitad=i;
                    break;
                }if(prob[i]=='+'){
                    op=6;
                    mitad=i;
                    break;
                }if(prob[i]=='*'){
                    op=7;
                    mitad=i;
                    break;
                }
            }
            string der="";
            for (int j = mitad+1; j < prob.size(); ++j) {
                der+=prob[j];
            }
            for (int j = 0; j < mitad; ++j) {
                izq+=prob[j];
            }
            cout<<op<<endl;
            int** m1;
            int** m2=NULL;
            if(op==1){
                cout<<"**********SUMA**********"<<endl;
                // Matriz(int size, const string &nombre, int **mat);
                for (int i = 0; i <matrices.size() ; ++i) {
                    for (int j = 0; j <matrices.size() ; ++j) {
                        if (matrices.at(i)->getNombre()==der&&matrices.at(j)->getNombre()==izq){
                            Matriz m(matrices.at(i)->getSize(),matrices.at(i)->getNombre(),matrices.at(i)->getMat());
                            m1=m|matrices.at(j)->getMat();
                            printIntMatrix(m1,matrices.at(i)->getSize());
                            i=10;
                            break;
                        }
                    }

                }

            } else if(op==2){
                for (int i = 0; i <matrices.size() ; ++i) {
                    if(matrices.at(i)->getNombre()==izq) {
                        Matriz m(matrices.at(i)->getSize(), matrices.at(i)->getNombre(), matrices.at(i)->getMat());
                        ++m;//matrices.at(j)->getMat();
                        //printIntMatrix(m1,matrices.at(i)->getSize());
                        break;
                    }
                }
            }else if(op==3){
                for (int i = 0; i <matrices.size() ; ++i) {
                    if(matrices.at(i)->getNombre()==izq) {
                        Matriz m(matrices.at(i)->getSize(), matrices.at(i)->getNombre(), matrices.at(i)->getMat());
                        --m;//matrices.at(j)->getMat();
                        //printIntMatrix(m1,matrices.at(i)->getSize());
                        break;
                    }
                }
            } else if(op==4){
                for (int i = 0; i <matrices.size() ; ++i) {
                        if (matrices.at(i)->getNombre()==izq){
                            Matriz m(matrices.at(i)->getSize(),matrices.at(i)->getNombre(),matrices.at(i)->getMat());
                            int r=std::stoi( der );
                            m1=m>r;
                            printIntMatrix(m1,matrices.at(i)->getSize());
                            break;
                        }
                }

            } else if(op==5){
                for (int i = 0; i <matrices.size() ; ++i) {
                    for (int j = 0; j <matrices.size() ; ++j) {
                        if (matrices.at(i)->getNombre()==der&&matrices.at(j)->getNombre()==izq){
                            Matriz m(matrices.at(i)->getSize(),matrices.at(i)->getNombre(),matrices.at(i)->getMat());
                            m1=m&matrices.at(j)->getMat();
                            printIntMatrix(m1,matrices.at(i)->getSize());
                            i=10;
                            break;
                        }
                    }

                }

            } else if(op==6){
                for (int i = 0; i <matrices.size() ; ++i) {
                    for (int j = 0; j <matrices.size() ; ++j) {
                        if (matrices.at(i)->getNombre()==der&&matrices.at(j)->getNombre()==izq){
                            Matriz m(matrices.at(i)->getSize(),matrices.at(i)->getNombre(),matrices.at(i)->getMat());
                            m1=m+matrices.at(j)->getMat();
                            printIntMatrix(m1,matrices.at(i)->getSize());
                            i=10;
                            break;
                        }
                    }

                }

            } else if(op==7){
                for (int i = 0; i <10 ; ++i) {
                    cout<<"QUERIA JUGAR POTRA :,v"<<endl;
                }
                cout<<"Lo demas esta weno salu2"<<endl;
            }

        } else if (des == 5) {
            wh=69;
        } else {
            cout << "Decision no valida" << endl;
        }


    }
    return 0;
}

void freeIntMatrix(int**& matrix,int size){
    //primero liberar las columnas de cada fila
    for(int i=0;i<size;i++){
        delete[] matrix[i];
        matrix[i]=NULL;
    }
    //liberar filas
    delete[] matrix;
    matrix=NULL;

}

int** createIntMatrix(int size){
    int** retVal=NULL;
    //provisionar las filas
    retVal=new int*[size];
    //provisionar las columnas de cada fila
    for(int i=0;i<size;i++){
        retVal[i]=new int [size];
    }

    return retVal;

}

//inicializar la matriz
void initIntMatrix(int** matrix,int size){
    cout<<"**********Rellenar Matriz***********"<<endl;
    int num;
    int aux=0;
    for(int i=0;i<size;i++) {
        for (int j = 0; j < size; j++) {
            cin>>num;
            matrix[i][j] = num;
        }
    }

}

//Imprimir la matriz

void printIntMatrix(int** matrix,int size){
    cout<<"Matriz de Enteros"<<endl;
    for(int i=0;i<size;i++){
        for(int j=0;j<size;j++){
            cout<<"  "<<matrix[i][j];
        }
        cout<<endl;
    }
    cout<<endl;
}

