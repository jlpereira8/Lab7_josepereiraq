//
// Created by jlpereira on 11/30/18.
//

#include "Matriz.h"
#include "iostream"

using std::cout;
using std::endl;

Matriz::Matriz() {}

Matriz::Matriz(int size, const string &nombre, int **mat) : size(size), nombre(nombre), mat(mat) {}

Matriz::~Matriz() {
    cout<<endl;
cout<<"Liberando Matriz Dinamica....."<<endl;
}

int Matriz::getSize() const {
    return size;
}

void Matriz::setSize(int size) {
    Matriz::size = size;
}

const string &Matriz::getNombre() const {
    return nombre;
}

void Matriz::setNombre(const string &nombre) {
    Matriz::nombre = nombre;
}

int **Matriz::getMat() const {
    return mat;
}

void Matriz::setMat(int **mat) {
    Matriz::mat = mat;
}

int Matriz::determinante() {
    if (size==2){
        int pos=mat[0][0]*mat[1][1];
        int neg=mat[0][1]*mat[1][0];
        return pos-neg;
    }else if (size==3){
        /*
        int pos1=mat[0][0]*mat[1][1]*mat[2][2];
        int pos2=mat[0][1]*mat[1][2]*mat[2][0];
        int pos3=mat[1][0]*mat[2][1]*mat[0][2];
        int sum=pos1+pos2+pos3;
        int neg1=mat[0][2]*mat[1][1]*mat[2][0];
        int neg2=mat[0][1]*mat[1][0]*mat[2][2];
        int neg3=mat[0][0]*mat[2][1]*mat[1][2];
        int res=neg1+neg2+neg3;
        return sum-res;
         */
        int ret=mat[0][0]*((mat[1][1]*mat[2][2])-(mat[1][2]*mat[2][1]))-mat[0][1]*((mat[1][0]*mat[2][2])-(mat[1][2]*mat[2][0]))+mat[0][2]*((mat[1][0]*mat[2][1])-(mat[1][1]*mat[2][0]));
        return ret;

    }

}

int** Matriz::operator|(int **m2) {
    int** retVal=NULL;
    if(size==2) {
        retVal = new int *[size];
        for (int i = 0; i < size; i++) {
            retVal[i] = new int[size];
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                retVal[i][j] = 0;
            }
        }
        retVal[0][0]=mat[0][0]+m2[0][0];
        retVal[0][1]=mat[0][1]+m2[0][1];
        retVal[1][0]=mat[1][0]+m2[1][0];
        retVal[1][1]=mat[1][1]+m2[1][1];

        return retVal;
    }else if(size==3){
        retVal = new int *[size];
        for (int i = 0; i < size; i++) {
            retVal[i] = new int[size];
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                retVal[i][j] = 0;
            }
        }
        retVal[0][0]=mat[0][0]+m2[0][0];
        retVal[0][1]=mat[0][1]+m2[0][1];
        retVal[0][2]=mat[0][2]+m2[0][2];

        retVal[1][0]=mat[1][0]+m2[1][0];
        retVal[1][1]=mat[1][1]+m2[1][1];
        retVal[1][2]=mat[1][2]+m2[1][2];

        retVal[2][0]=mat[2][0]+m2[2][0];
        retVal[2][1]=mat[2][1]+m2[2][1];
        retVal[2][2]=mat[2][2]+m2[2][2];

        return retVal;
    }



}

void Matriz::operator++() {
    int k = abs(determinante()-size);
        for (int i = 0; i < size ; ++i) {
            for (int j = 0; j <size ; ++j) {
                mat[i][j]+=k;
            }
        }
        cout<<"**********Incremento**********"<<endl;
        for(int i=0;i<size;i++){
            for(int j=0;j<size;j++){
                cout<<"  "<<mat[i][j];
            }
            cout<<endl;
        }
        cout<<endl;

}

int **Matriz::operator>(int k) {

        for (int i = 0; i < size ; ++i) {
            for (int j = 0; j <size ; ++j) {
                mat[i][j]=mat[i][j]*k;
            }
        }
        return mat;

}

void Matriz::operator--() {
    int k = abs(determinante()-size);
    for (int i = 0; i < size ; ++i) {
        for (int j = 0; j <size ; ++j) {
            mat[i][j]-=k;
        }
    }
    cout<<"**********Incremento**********"<<endl;
    for(int i=0;i<size;i++){
        for(int j=0;j<size;j++){
            cout<<"  "<<mat[i][j];
        }
        cout<<endl;
    }
    cout<<endl;
}

int **Matriz::operator&(int** m) {
    int **retVal = NULL;
    if (size == 3) {
        retVal = new int *[size];
        for (int i = 0; i < size; i++) {
            retVal[i] = new int[size];
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                retVal[i][j] = 0;
            }
        }

        retVal[0][0]=(mat[0][0]*m[0][0])+(mat[0][1]*m[1][0])+(mat[0][2]*mat[2][0]);
        retVal[0][1]=(mat[0][0]*m[0][1])+(mat[0][1]*m[1][1])+(mat[0][2]*mat[2][1]);
        retVal[0][2]=(mat[0][0]*m[0][2])+(mat[0][1]*m[1][2])+(mat[0][2]*mat[2][2]);

        retVal[1][0]=(mat[1][0]*m[0][0])+(mat[1][1]*m[1][0])+(mat[1][2]*mat[2][0]);
        retVal[1][1]=(mat[1][0]*m[0][1])+(mat[1][1]*m[1][1])+(mat[1][2]*mat[2][1]);
        retVal[1][2]=(mat[1][0]*m[0][2])+(mat[1][1]*m[1][2])+(mat[1][2]*mat[2][2]);

        retVal[2][0]=(mat[2][0]*m[0][0])+(mat[2][1]*m[1][0])+(mat[2][2]*mat[2][0]);
        retVal[2][1]=(mat[2][0]*m[0][1])+(mat[2][1]*m[1][1])+(mat[2][2]*mat[2][1]);
        retVal[2][2]=(mat[2][0]*m[0][2])+(mat[2][1]*m[1][2])+(mat[2][2]*mat[2][2]);

        return retVal;
    }else if(size==2){
        retVal = new int *[size];
        for (int i = 0; i < size; i++) {
            retVal[i] = new int[size];
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                retVal[i][j] = 0;
            }
        }
        retVal[0][0]=(mat[0][0]*m[0][0])+(mat[0][1]*m[1][0]);
        retVal[0][1]=(mat[0][0]*m[0][1])+(mat[0][1]*m[1][1]);

        retVal[1][0]=(mat[1][0]*m[0][0])+(mat[1][1]*m[1][0]);
        retVal[1][1]=(mat[1][0]*m[0][1])+(mat[1][1]*m[1][1]);

        return retVal;
    }
}

int **Matriz::operator+(int **m) {
    int **retVal = NULL;
    if (size == 2) {
        retVal = new int *[size];
        for (int i = 0; i < size; i++) {
            retVal[i] = new int[size];
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                retVal[i][j] = 0;
            }
        }
        retVal[0][0] = mat[0][0] + m[0][0];
        retVal[0][1] = 2 * (mat[0][1] + m[0][1]);
        retVal[1][0] = mat[1][0] + m[1][0];
        retVal[1][1] = 2 * (mat[1][1] + m[1][1]);

        return retVal;
    } else if (size == 3) {
        retVal = new int *[size];
        for (int i = 0; i < size; i++) {
            retVal[i] = new int[size];
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                retVal[i][j] = 0;
            }
        }
        retVal[0][0] = 3 * (mat[0][0] + m[0][0]);
        retVal[0][1] = mat[0][1] + m[0][1];
        retVal[0][2] = mat[0][2] + m[0][2];

        retVal[1][0] = mat[1][0] + m[1][0];
        retVal[1][1] = 3 * (mat[1][1] + m[1][1]);
        retVal[1][2] = mat[1][2] + m[1][2];

        retVal[2][0] = mat[2][0] + m[2][0];
        retVal[2][1] = mat[2][1] + m[2][1];
        retVal[2][2] = 3 * (mat[2][2] + m[2][2]);

        return retVal;

    }
}



